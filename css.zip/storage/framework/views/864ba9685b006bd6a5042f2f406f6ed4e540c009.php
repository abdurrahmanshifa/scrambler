

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Score')); ?></div>

                <div class="card-body">
                    <a class="btn btn-primary" href="<?php echo e(route('play',['id' => '5'])); ?>" style="margin-bottom: 20px;">
                        <?php echo e(__('Play')); ?>

                    </a>
                    <table class="table table-bordered" id="score-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Score</th>
                                <th>Level</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(function() {
    var table = $('#score-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route("home")); ?>',
        columns: [
            { data: 'name', name: 'name' },
            { data: 'score', name: 'score' },
            { data: 'level', name: 'level' },
            { data: 'date', name: 'date' }
        ],
    });

    $('.searchtype').on('change', function() {
        table.draw();
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\scrambler\resources\views/home.blade.php ENDPATH**/ ?>