

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Nouns')); ?></div>
                <div class="card-body">
                    <a class="btn btn-primary" href="<?php echo e(route('admin.get-nouns')); ?>" style="margin-bottom: 20px;">
                        <?php echo e(__('Get Nouns')); ?>

                    </a>
                    <table class="table table-bordered" id="score-table">
                        <thead>
                            <tr>
                                <th>Text</th>
                                <th>Jumlah Kata</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(function() {
    var table = $('#score-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route("admin.nouns")); ?>',
        columns: [
            { data: 'text', name: 'text' },
            { data: 'count', name: 'count' },
            { data: 'date', name: 'date' }
        ],
    });

    $('.searchtype').on('change', function() {
        table.draw();
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\scrambler\resources\views/admin/nouns.blade.php ENDPATH**/ ?>